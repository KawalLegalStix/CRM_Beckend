// app.js
const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');
const leadRoutes = require('./routes/routes');
const path = require('path');
const cors = require('cors'); // Add this line


const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, 'build')));
// Handle requests that don't match the static files
// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, 'build', 'index.html'));
// });

app.set('trust proxy', true);
// Allow requests from all origins (for testing purposes)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  next();
});

app.use(bodyParser.json());
app.use('/auth', authRoutes);
app.use('/lead', leadRoutes);

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'build', 'index.html'));
 });

app.get('/', (req, res) => {
  res.send('Node.js Setup Success!')
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
}); 
