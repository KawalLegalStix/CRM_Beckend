// routes/authRoutes.js
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.post('/login', authController.login);

module.exports = router;
// nj!AhX2dO;l$


//DB
//pass:B3lL#%-d@[r2   oZM47HeE=$_o   eEilff?!I?2^
//name: DevKawal