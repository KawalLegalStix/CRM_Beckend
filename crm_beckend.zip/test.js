const arr = [3, 9, 8, 4, 2, 4, 4, 3, 2,  34 ,4, 1];

var NewArr = [];
var DuplicateArr = [];
for(var i  = 0; i <= arr.length - 1; i++){
         
       let isDuplicate = false;
       let IsDuplicateInDuplicate = false;
       for(var j = 0; j <= arr.length - 1; j++){
               if(NewArr[j] == arr[i]){
                     isDuplicate = true; 
               }

               if(DuplicateArr[j] == arr[i]){
                     IsDuplicateInDuplicate = true; 
               }
       }

       if(!isDuplicate){
             NewArr.push(arr[i]);
       }
       if(isDuplicate && !IsDuplicateInDuplicate){
              DuplicateArr.push(arr[i]);
        }
}

console.log(DuplicateArr)